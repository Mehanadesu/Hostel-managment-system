<h> HOSTELHUB - THE HOSTEL MANAGEMENT SYSTEM </h> <br>
<b> Contributors : 
<ul>
<li> <a href="https://github.com/Saumya40-codes" target = "__blank" >Saumya Shah </a> </li>
<li> <a href="https://github.com/Codesmith28" target = "__blank" >Sarthak Siddhpura </a> </li>
</ul> <br>
  We mainted this whole project repository since we started it -> <a href = "https://github.com/Codesmith28/Hostel-Hub" target = "__blank" > You can check it out here ! </a> <br>
<b>Primary Tech Stack Used:</b>
<dl>
<li> HTML5 </li>
<li> CSS </li>
<li> FLask </li>
</dl>
In flask we have used many modules like <b> SQLALchemy, werkzeug.security , Flask Login </b> and many more !!
Before detail information about website , you can check it out by pressing the below link <br> <br>
<a href = "http://hostelhub.pythonanywhere.com/" targer="__blank" > HostelHub - The Hostel Management System </a> <br> <br>

In this you can create warden account by signing up and then by loging in it , you can add the login credential of hostellite using add hostellite option in it.
We have tried to keep it that way so that while creating hostellite account warden can allot him room number aswell and there will be no need for hostellite to make an account

  <h1> Some Features and working of our website: </h1> <br>
  <ol type='a'>
    <li> Warden side </li>
    Add hostellite : In this firstly what warden can do is to create the database of the hostellite and can also allot him a room and if that room is already occuppied, he will get to know that as well as an error <br> <br>
    Add menu : Here warden can add the day-to-day mess menu for hostellite which will be shown on hostellites side <br>
    Get Queries : Here warden can read the queries which is sent by hostellites <br>
    Check fee status : In this warden will be able to see, who has paid the fee and who hasn't and for those who have paid the fees directly through our side, warden will be able to show the information which got submitted while paying fees ( including the screenshot of paid message submitted by hostellite !! )
    <li> Hostellite Side </li>
    In profile section he will be able to  add/update additional details <br>
    Mess menu will be shown to him in dashboard only <br>
    Send Queries/Messages to Warden <br>
    Can pay fees after attaching the screenshot of paid fees message <br>
    Can search his other fellow hostellites and can get some details of them, whose database has been created on our site.
  </ol>
    <br>
  <div class="imgs">
    <label> Home Page </label> <br>
  <img src="https://user-images.githubusercontent.com/115284013/233756268-883b0fdf-838f-4613-b51d-60aefbe01e31.png" width = 1450px height = 650px> <br>
    <label> Hostellite account creation page on warden side </label>
  <img src="https://user-images.githubusercontent.com/115284013/233756478-fa4f7e1c-ec87-40f0-a7e2-82cf2fb33563.png" width = 1450px height = 550px > <br>
    <label> Mess menu adding page (warden side) <br>
  <img src = "https://user-images.githubusercontent.com/115284013/233756563-13fa1a84-12c4-40e4-ab21-acd9c6573b55.png" width = 1450px height = 550px >  <br>
    <label> Checking messages or queries page from hostellites  <br>
  <img src = "https://user-images.githubusercontent.com/115284013/233756818-f2a778e9-4463-4da5-abf4-5987c4a2bb20.png"  width = 1450px height = 550px >   <br>
      <label> Fee status page </label>
  <img src = "https://user-images.githubusercontent.com/115284013/235099351-c7320429-1b41-480d-8dd8-b728e4861597.png" width = 1450px height = 550px> <br>
      <b> There are other warden side features as well which are not covered here but you check them on our site </b>  <br>  <br> 
    <label> Dashboard (Hostellite Side)
  <img src = "https://user-images.githubusercontent.com/115284013/233756915-f7b9c913-8207-47e9-9ad5-4909f6170439.png"  width = 1450px height = 550px> <br>
    <label> Page to find other fellow hostellites </label>  <br>
  <img src = "https://user-images.githubusercontent.com/115284013/233757057-e32490d1-bd9c-4f41-8278-42d4d07bd30e.png" width = 1450px height = 550px> <br>
    <label> Page to send queries/messages </label>   <br> 
  <img src = "https://user-images.githubusercontent.com/115284013/233757222-ffc076f7-0b83-4eec-9b1c-cc28aa5b9f6e.png" width = 1450px height = 550px> <br> <br> <br> <br> <br>
      <b> check other features only  on our site !! </b>


